#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <math.h>
#include "graph.h"
#include "dijkstra.h"
#include "astar.h"

// High-resolution timer in microseconds
static double get_time_us(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (double)ts.tv_sec * 1000000.0 + (double)ts.tv_nsec / 1000.0;
}

static void benchmark_dijkstra(const Graph* g, int start, int dest, RouteResult* res, int iterations) {
    dijkstra_solve(g, start, dest, res);
    if (iterations <= 1) return;

    double t0 = get_time_us();
    for (int i = 0; i < iterations; i++) {
        RouteResult dummy;
        dijkstra_solve(g, start, dest, &dummy);
    }
    double t1 = get_time_us();
    res->execution_time_us = (t1 - t0) / (double)iterations;
}

static void benchmark_astar(const Graph* g, int start, int dest, RouteResult* res, int iterations) {
    astar_solve(g, start, dest, res);
    if (iterations <= 1) return;

    double t0 = get_time_us();
    for (int i = 0; i < iterations; i++) {
        RouteResult dummy;
        astar_solve(g, start, dest, &dummy);
    }
    double t1 = get_time_us();
    res->execution_time_us = (t1 - t0) / (double)iterations;
}

static void print_usage(const char* prog) {
    fprintf(stderr, "Usage: %s [options]\n", prog);
    fprintf(stderr, "Options:\n");
    fprintf(stderr, "  --graph                   Print simulated SRM AP campus graph as JSON\n");
    fprintf(stderr, "  --algo <dijkstra|astar|both>  Algorithm to run (default: both)\n");
    fprintf(stderr, "  --start <node_id>         Start location ID (0-15)\n");
    fprintf(stderr, "  --dest <node_id>          Destination hospital ID (0-15, default: 15)\n");
    fprintf(stderr, "  --trials <num>            Number of benchmark iterations (default: 500)\n");
    fprintf(stderr, "  --help                    Show this help message\n");
}

int main(int argc, char* argv[]) {
    Graph* g = graph_init_srm_campus();
    if (!g) {
        fprintf(stderr, "Error: Failed to initialize campus graph.\n");
        return 1;
    }

    bool opt_graph = false;
    char opt_algo[32] = "both";
    int opt_start = 0;   // Default: Main Entrance Gate
    int opt_dest = 15;   // Default: University Health Care & Emergency Hospital
    int opt_trials = 500;

    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--graph") == 0) {
            opt_graph = true;
        } else if (strcmp(argv[i], "--algo") == 0 && i + 1 < argc) {
            strncpy(opt_algo, argv[++i], sizeof(opt_algo) - 1);
        } else if (strcmp(argv[i], "--start") == 0 && i + 1 < argc) {
            opt_start = atoi(argv[++i]);
        } else if (strcmp(argv[i], "--dest") == 0 && i + 1 < argc) {
            opt_dest = atoi(argv[++i]);
        } else if (strcmp(argv[i], "--trials") == 0 && i + 1 < argc) {
            opt_trials = atoi(argv[++i]);
        } else if (strcmp(argv[i], "--help") == 0) {
            print_usage(argv[0]);
            graph_destroy(g);
            return 0;
        }
    }

    if (opt_graph) {
        graph_print_json(g);
        graph_destroy(g);
        return 0;
    }

    if (opt_start < 0 || opt_start >= g->num_nodes || opt_dest < 0 || opt_dest >= g->num_nodes) {
        fprintf(stderr, "Error: Start (%d) or Dest (%d) out of range [0, %d].\n",
                opt_start, opt_dest, g->num_nodes - 1);
        graph_destroy(g);
        return 1;
    }

    if (strcmp(opt_algo, "dijkstra") == 0) {
        RouteResult res;
        benchmark_dijkstra(g, opt_start, opt_dest, &res, opt_trials);
        route_result_print_json(&res);
    } else if (strcmp(opt_algo, "astar") == 0) {
        RouteResult res;
        benchmark_astar(g, opt_start, opt_dest, &res, opt_trials);
        route_result_print_json(&res);
    } else {
        // Run both algorithms and output combined comparison JSON
        RouteResult dijkstra_res;
        RouteResult astar_res;

        benchmark_dijkstra(g, opt_start, opt_dest, &dijkstra_res, opt_trials);
        benchmark_astar(g, opt_start, opt_dest, &astar_res, opt_trials);

        int expanded_saved = dijkstra_res.num_expanded - astar_res.num_expanded;
        double saved_pct = (dijkstra_res.num_expanded > 0)
            ? ((double)expanded_saved / (double)dijkstra_res.num_expanded) * 100.0
            : 0.0;

        printf("{\n");
        printf("  \"dijkstra\": ");
        route_result_print_json(&dijkstra_res);
        printf(",\n");
        printf("  \"astar\": ");
        route_result_print_json(&astar_res);
        printf(",\n");
        printf("  \"comparison\": {\n");
        printf("    \"optimal_travel_time_match\": %s,\n",
               fabs(dijkstra_res.total_time_min - astar_res.total_time_min) < 1e-4 ? "true" : "false");
        printf("    \"time_difference_min\": %.4f,\n",
               fabs(dijkstra_res.total_time_min - astar_res.total_time_min));
        printf("    \"dijkstra_expanded\": %d,\n", dijkstra_res.num_expanded);
        printf("    \"astar_expanded\": %d,\n", astar_res.num_expanded);
        printf("    \"expanded_difference\": %d,\n", expanded_saved);
        printf("    \"expanded_reduction_pct\": %.1f,\n", saved_pct);
        printf("    \"dijkstra_exec_time_us\": %.2f,\n", dijkstra_res.execution_time_us);
        printf("    \"astar_exec_time_us\": %.2f\n", astar_res.execution_time_us);
        printf("  }\n");
        printf("}\n");
    }

    graph_destroy(g);
    return 0;
}
