#include "heap.h"
#include <stdlib.h>
#include <stdio.h>

MinHeap* heap_create(int capacity) {
    if (capacity <= 0) capacity = 64;
    MinHeap* heap = (MinHeap*)malloc(sizeof(MinHeap));
    if (!heap) return NULL;

    heap->elements = (HeapElement*)malloc(sizeof(HeapElement) * capacity);
    if (!heap->elements) {
        free(heap);
        return NULL;
    }
    heap->size = 0;
    heap->capacity = capacity;
    return heap;
}

void heap_destroy(MinHeap* heap) {
    if (heap) {
        if (heap->elements) {
            free(heap->elements);
        }
        free(heap);
    }
}

static void swap_elements(HeapElement* a, HeapElement* b) {
    HeapElement tmp = *a;
    *a = *b;
    *b = tmp;
}

void heap_push(MinHeap* heap, int node_id, double priority) {
    if (!heap) return;
    if (heap->size >= heap->capacity) {
        int new_cap = heap->capacity * 2;
        HeapElement* new_elems = (HeapElement*)realloc(heap->elements, sizeof(HeapElement) * new_cap);
        if (!new_elems) return;
        heap->elements = new_elems;
        heap->capacity = new_cap;
    }

    int idx = heap->size++;
    heap->elements[idx].node_id = node_id;
    heap->elements[idx].priority = priority;

    // Sift up
    while (idx > 0) {
        int parent = (idx - 1) / 2;
        if (heap->elements[idx].priority < heap->elements[parent].priority) {
            swap_elements(&heap->elements[idx], &heap->elements[parent]);
            idx = parent;
        } else {
            break;
        }
    }
}

bool heap_pop(MinHeap* heap, HeapElement* out_elem) {
    if (!heap || heap->size == 0) return false;

    if (out_elem) {
        *out_elem = heap->elements[0];
    }

    heap->elements[0] = heap->elements[heap->size - 1];
    heap->size--;

    // Sift down
    int idx = 0;
    while (true) {
        int left = 2 * idx + 1;
        int right = 2 * idx + 2;
        int smallest = idx;

        if (left < heap->size && heap->elements[left].priority < heap->elements[smallest].priority) {
            smallest = left;
        }
        if (right < heap->size && heap->elements[right].priority < heap->elements[smallest].priority) {
            smallest = right;
        }

        if (smallest != idx) {
            swap_elements(&heap->elements[idx], &heap->elements[smallest]);
            idx = smallest;
        } else {
            break;
        }
    }

    return true;
}

bool heap_is_empty(const MinHeap* heap) {
    return (!heap || heap->size == 0);
}
