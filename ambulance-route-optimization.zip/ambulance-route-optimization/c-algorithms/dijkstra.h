#ifndef DIJKSTRA_H
#define DIJKSTRA_H

#include "graph.h"

/**
 * Executes Dijkstra's algorithm to compute the shortest travel-time path.
 *
 * @param g Graph representing campus road network.
 * @param start Source node ID.
 * @param dest Destination node ID.
 * @param result Pointer to RouteResult structure where metrics and route are stored.
 * @return true if a route was found, false otherwise.
 */
bool dijkstra_solve(const Graph* g, int start, int dest, RouteResult* result);

#endif // DIJKSTRA_H
