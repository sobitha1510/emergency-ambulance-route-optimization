#ifndef HEAP_H
#define HEAP_H

#include <stdbool.h>

/**
 * Min-Heap Element representing a graph node and its priority value.
 * For Dijkstra: priority = g_score (shortest travel time from start).
 * For A*: priority = f_score = g_score + h (travel time + heuristic).
 */
typedef struct {
    int node_id;
    double priority;
} HeapElement;

typedef struct {
    HeapElement* elements;
    int size;
    int capacity;
} MinHeap;

MinHeap* heap_create(int capacity);
void heap_destroy(MinHeap* heap);
void heap_push(MinHeap* heap, int node_id, double priority);
bool heap_pop(MinHeap* heap, HeapElement* out_elem);
bool heap_is_empty(const MinHeap* heap);

#endif // HEAP_H
