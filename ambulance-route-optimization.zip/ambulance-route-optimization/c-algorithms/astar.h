#ifndef ASTAR_H
#define ASTAR_H

#include "graph.h"

/**
 * Executes A* search algorithm using an admissible straight-line travel-time heuristic.
 *
 * @param g Graph representing campus road network.
 * @param start Source node ID.
 * @param dest Destination node ID.
 * @param result Pointer to RouteResult structure where metrics and route are stored.
 * @return true if a route was found, false otherwise.
 */
bool astar_solve(const Graph* g, int start, int dest, RouteResult* result);

#endif // ASTAR_H
