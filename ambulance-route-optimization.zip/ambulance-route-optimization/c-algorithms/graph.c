#include "graph.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

Graph* graph_create(int max_nodes, double max_speed_kmh) {
    Graph* g = (Graph*)malloc(sizeof(Graph));
    if (!g) return NULL;

    g->max_nodes = max_nodes;
    g->num_nodes = 0;
    g->max_speed_kmh = max_speed_kmh;
    g->nodes = (Node*)calloc(max_nodes, sizeof(Node));
    if (!g->nodes) {
        free(g);
        return NULL;
    }
    return g;
}

void graph_destroy(Graph* g) {
    if (!g) return;
    for (int i = 0; i < g->num_nodes; i++) {
        Edge* curr = g->nodes[i].edges;
        while (curr) {
            Edge* tmp = curr;
            curr = curr->next;
            free(tmp);
        }
    }
    free(g->nodes);
    free(g);
}

bool graph_add_node(Graph* g, int id, const char* code, const char* name, const char* category, double x, double y) {
    if (!g || id < 0 || id >= g->max_nodes) return false;

    Node* node = &g->nodes[id];
    node->id = id;
    strncpy(node->code, code, MAX_CODE_LEN - 1);
    node->code[MAX_CODE_LEN - 1] = '\0';
    strncpy(node->name, name, MAX_NAME_LEN - 1);
    node->name[MAX_NAME_LEN - 1] = '\0';
    strncpy(node->category, category, sizeof(node->category) - 1);
    node->category[sizeof(node->category) - 1] = '\0';
    node->x = x;
    node->y = y;
    node->edges = NULL;

    if (id >= g->num_nodes) {
        g->num_nodes = id + 1;
    }
    return true;
}

bool graph_add_edge(Graph* g, int u, int v, double length_m, double speed_kmh, const char* road_name) {
    if (!g || u < 0 || u >= g->num_nodes || v < 0 || v >= g->num_nodes) return false;

    Edge* edge = (Edge*)malloc(sizeof(Edge));
    if (!edge) return false;

    edge->target = v;
    edge->length_m = length_m;
    edge->speed_kmh = speed_kmh;
    // Travel time in minutes: (length_m / (speed_kmh * 1000 / 60)) = (length_m * 60) / (speed_kmh * 1000)
    edge->travel_time_min = (length_m * 60.0) / (speed_kmh * 1000.0);

    strncpy(edge->road_name, road_name, MAX_NAME_LEN - 1);
    edge->road_name[MAX_NAME_LEN - 1] = '\0';

    // Insert at front of adjacency list
    edge->next = g->nodes[u].edges;
    g->nodes[u].edges = edge;

    return true;
}

bool graph_add_edge_bidirectional(Graph* g, int u, int v, double length_m, double speed_kmh, const char* road_name) {
    bool ok1 = graph_add_edge(g, u, v, length_m, speed_kmh, road_name);
    bool ok2 = graph_add_edge(g, v, u, length_m, speed_kmh, road_name);
    return ok1 && ok2;
}

double graph_euclidean_distance(const Graph* g, int u, int v) {
    if (!g || u < 0 || u >= g->num_nodes || v < 0 || v >= g->num_nodes) return 0.0;
    double dx = g->nodes[u].x - g->nodes[v].x;
    double dy = g->nodes[u].y - g->nodes[v].y;
    return sqrt(dx * dx + dy * dy);
}

double graph_heuristic(const Graph* g, int u, int dest) {
    if (!g || u < 0 || u >= g->num_nodes || dest < 0 || dest >= g->num_nodes) return 0.0;
    double dist = graph_euclidean_distance(g, u, dest);
    // Convert max speed km/h to meters per minute
    double max_speed_m_per_min = (g->max_speed_kmh * 1000.0) / 60.0;
    // h(u) in minutes
    return dist / max_speed_m_per_min;
}

Graph* graph_init_srm_campus(void) {
    // Max campus road speed is 40.0 km/h
    Graph* g = graph_create(16, 40.0);
    if (!g) return NULL;

    // 16 Simulated SRM University AP campus landmarks
    graph_add_node(g, 0,  "GATE",     "Main Entrance Gate",                 "Entrance",     80.0,  350.0);
    graph_add_node(g, 1,  "SEC",      "Security Roundabout & Welcome Bay",  "Facility",    200.0,  350.0);
    graph_add_node(g, 2,  "PARK",     "West Parking & Transit Bus Bay",     "Facility",    180.0,  530.0);
    graph_add_node(g, 3,  "ADMIN",    "Admin Block (Subhash Chandra Bose)", "Academic",    340.0,  320.0);
    graph_add_node(g, 4,  "MECH",     "Mechanical & Robotics Workshops",    "Academic",    320.0,  530.0);
    graph_add_node(g, 5,  "ACAD1",    "Academic Block 1 (Lecture Theatres)","Academic",    480.0,  220.0);
    graph_add_node(g, 6,  "ACAD2",    "Academic Block 2 (Computing Labs)",  "Academic",    520.0,  360.0);
    graph_add_node(g, 7,  "LIB",      "Central Library & Knowledge Hub",    "Academic",    400.0,  450.0);
    graph_add_node(g, 8,  "SAC",      "Student Activity Centre (Auditorium)","Amenity",    650.0,  220.0);
    graph_add_node(g, 9,  "MESS",     "Central Dining & Rock Plaza",        "Amenity",     620.0,  440.0);
    graph_add_node(g, 10, "SPORTS",   "Indoor Sports Complex & Gym",        "Sports",      620.0,  600.0);
    graph_add_node(g, 11, "TRACK",    "Athletic Track & Sports Arena",      "Sports",      820.0,  610.0);
    graph_add_node(g, 12, "HOST_B",   "Ganga-Godavari Boys Hostel Complex", "Hostel",      840.0,  460.0);
    graph_add_node(g, 13, "HOST_G",   "Narmada-Yamuna Girls Hostel Complex","Hostel",      840.0,  310.0);
    graph_add_node(g, 14, "FACULTY",  "Faculty Enclave & Guest House",      "Residential", 800.0,  160.0);
    graph_add_node(g, 15, "HOSP",     "University Health Care & Emergency", "Medical",     480.0,   70.0);

    // Bidirectional road segments
    graph_add_edge_bidirectional(g, 0,  1,  120.0, 40.0, "Grand Campus Avenue");
    graph_add_edge_bidirectional(g, 1,  2,  190.0, 30.0, "West Parking Boulevard");
    graph_add_edge_bidirectional(g, 1,  3,  150.0, 35.0, "Central Avenue West");
    graph_add_edge_bidirectional(g, 2,  4,  140.0, 25.0, "South Perimeter Road");
    graph_add_edge_bidirectional(g, 3,  4,  220.0, 30.0, "Engineering Workshop Way");
    graph_add_edge_bidirectional(g, 3,  5,  180.0, 35.0, "Administration North Link");
    graph_add_edge_bidirectional(g, 3,  6,  190.0, 30.0, "Chandra Bose Central Walk");
    graph_add_edge_bidirectional(g, 4,  7,  120.0, 25.0, "Library South Approach");
    graph_add_edge_bidirectional(g, 5,  6,  150.0, 30.0, "Academic Quadrangle Road");
    graph_add_edge_bidirectional(g, 5,  8,  170.0, 40.0, "Innovation Corridor");
    graph_add_edge_bidirectional(g, 5,  15, 150.0, 40.0, "Hospital Emergency Arterial");
    graph_add_edge_bidirectional(g, 6,  7,  150.0, 30.0, "Research Knowledge Walk");
    graph_add_edge_bidirectional(g, 6,  9,  135.0, 35.0, "Campus Central Heart Way");
    graph_add_edge_bidirectional(g, 7,  9,  225.0, 25.0, "Canteen Promenade");
    graph_add_edge_bidirectional(g, 7,  10, 270.0, 30.0, "Sports West Avenue");
    graph_add_edge_bidirectional(g, 8,  14, 170.0, 35.0, "Faculty North Drive");
    graph_add_edge_bidirectional(g, 8,  13, 215.0, 30.0, "Girls Hostel North Access");
    graph_add_edge_bidirectional(g, 8,  9,  225.0, 30.0, "SAC Plaza Bypass");
    graph_add_edge_bidirectional(g, 9,  10, 160.0, 25.0, "Recreation Lane");
    graph_add_edge_bidirectional(g, 9,  12, 225.0, 35.0, "Boys Hostel West Road");
    graph_add_edge_bidirectional(g, 10, 11, 205.0, 35.0, "Athletic Stadium Ring");
    graph_add_edge_bidirectional(g, 11, 12, 155.0, 30.0, "Hostel South Perimeter");
    graph_add_edge_bidirectional(g, 12, 13, 150.0, 25.0, "Hostel Quad Connector");
    graph_add_edge_bidirectional(g, 13, 14, 160.0, 35.0, "East Residential Drive");
    graph_add_edge_bidirectional(g, 14, 15, 340.0, 40.0, "Hospital North Perimeter Road");

    return g;
}

void graph_print_json(const Graph* g) {
    if (!g) {
        printf("{}\n");
        return;
    }

    printf("{\n");
    printf("  \"num_nodes\": %d,\n", g->num_nodes);
    printf("  \"max_speed_kmh\": %.1f,\n", g->max_speed_kmh);
    printf("  \"nodes\": [\n");
    for (int i = 0; i < g->num_nodes; i++) {
        const Node* n = &g->nodes[i];
        printf("    {\"id\": %d, \"code\": \"%s\", \"name\": \"%s\", \"category\": \"%s\", \"x\": %.1f, \"y\": %.1f}%s\n",
               n->id, n->code, n->name, n->category, n->x, n->y, (i == g->num_nodes - 1) ? "" : ",");
    }
    printf("  ],\n");

    printf("  \"edges\": [\n");
    bool first_edge = true;
    for (int i = 0; i < g->num_nodes; i++) {
        Edge* e = g->nodes[i].edges;
        while (e) {
            // Only output each undirected edge once (u < v)
            if (i < e->target) {
                if (!first_edge) printf(",\n");
                printf("    {\"u\": %d, \"v\": %d, \"length_m\": %.1f, \"speed_kmh\": %.1f, \"travel_time_min\": %.4f, \"road_name\": \"%s\"}",
                       i, e->target, e->length_m, e->speed_kmh, e->travel_time_min, e->road_name);
                first_edge = false;
            }
            e = e->next;
        }
    }
    printf("\n  ]\n");
    printf("}\n");
}

void route_result_print_json(const RouteResult* res) {
    if (!res) {
        printf("{}\n");
        return;
    }

    printf("{\n");
    printf("  \"algorithm\": \"%s\",\n", res->algorithm_name);
    printf("  \"start_node\": %d,\n", res->start_node);
    printf("  \"dest_node\": %d,\n", res->dest_node);
    printf("  \"found\": %s,\n", res->found ? "true" : "false");
    printf("  \"total_time_min\": %.4f,\n", res->total_time_min);
    printf("  \"total_distance_m\": %.2f,\n", res->total_distance_m);
    printf("  \"num_expanded\": %d,\n", res->num_expanded);
    printf("  \"execution_time_us\": %.2f,\n", res->execution_time_us);

    printf("  \"expanded_order\": [");
    for (int i = 0; i < res->num_expanded; i++) {
        printf("%d%s", res->expanded_order[i], (i == res->num_expanded - 1) ? "" : ", ");
    }
    printf("],\n");

    printf("  \"route_nodes\": [");
    for (int i = 0; i < res->route_length; i++) {
        printf("%d%s", res->route_nodes[i], (i == res->route_length - 1) ? "" : ", ");
    }
    printf("]\n");
    printf("}\n");
}
