#ifndef GRAPH_H
#define GRAPH_H

#include <stdbool.h>

#define MAX_NODES 32
#define MAX_NAME_LEN 64
#define MAX_CODE_LEN 16

/**
 * Representation of a directed edge in the adjacency list.
 * Roads are modeled as bidirectional pairs of directed edges.
 */
typedef struct Edge {
    int target;                 // Target node ID
    double length_m;            // Road length in meters
    double speed_kmh;           // Speed limit in km/h
    double travel_time_min;     // Base travel time in minutes: (length_m * 60.0) / (speed_kmh * 1000.0)
    char road_name[MAX_NAME_LEN]; // Name of the road/avenue
    struct Edge* next;          // Pointer to next edge
} Edge;

/**
 * Representation of a campus location/intersection node.
 */
typedef struct Node {
    int id;                     // Unique node ID (0 to N-1)
    char code[MAX_CODE_LEN];    // Short identifier (e.g., "HOSP", "GATE")
    char name[MAX_NAME_LEN];    // Full location name
    char category[32];          // Category: "Medical", "Academic", "Hostel", "Sports", "Entrance", "Facility"
    double x;                   // X coordinate in meters
    double y;                   // Y coordinate in meters
    Edge* edges;                // Adjacency list of outgoing edges
} Node;

/**
 * Graph structure representing the campus road network.
 */
typedef struct Graph {
    int num_nodes;
    int max_nodes;
    double max_speed_kmh;       // Maximum campus road speed (used for admissible A* heuristic)
    Node* nodes;
} Graph;

/**
 * Route result structure containing metrics from Dijkstra or A* search.
 */
typedef struct RouteResult {
    char algorithm_name[32];
    int start_node;
    int dest_node;
    bool found;
    double total_time_min;
    double total_distance_m;
    int num_expanded;
    int expanded_order[MAX_NODES];
    int route_length;
    int route_nodes[MAX_NODES];
    double execution_time_us;
} RouteResult;

Graph* graph_create(int max_nodes, double max_speed_kmh);
void graph_destroy(Graph* g);
bool graph_add_node(Graph* g, int id, const char* code, const char* name, const char* category, double x, double y);
bool graph_add_edge(Graph* g, int u, int v, double length_m, double speed_kmh, const char* road_name);
bool graph_add_edge_bidirectional(Graph* g, int u, int v, double length_m, double speed_kmh, const char* road_name);

/**
 * Admissible and consistent straight-line distance heuristic for A* in minutes.
 * h(u, dest) = straight_line_distance(u, dest) / max_speed_m_per_min
 */
double graph_heuristic(const Graph* g, int u, int dest);

/**
 * Calculates Euclidean distance between two nodes in meters.
 */
double graph_euclidean_distance(const Graph* g, int u, int v);

/**
 * Populates the graph with the simulated SRM University AP campus network.
 */
Graph* graph_init_srm_campus(void);

/**
 * Prints the entire graph structure as JSON to stdout.
 */
void graph_print_json(const Graph* g);

/**
 * Prints a RouteResult as JSON to stdout.
 */
void route_result_print_json(const RouteResult* res);

#endif // GRAPH_H
