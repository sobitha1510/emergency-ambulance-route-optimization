#include "astar.h"
#include "heap.h"
#include <float.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

bool astar_solve(const Graph* g, int start, int dest, RouteResult* result) {
    if (!g || !result || start < 0 || start >= g->num_nodes || dest < 0 || dest >= g->num_nodes) {
        return false;
    }

    memset(result, 0, sizeof(RouteResult));
    strncpy(result->algorithm_name, "A*", sizeof(result->algorithm_name) - 1);
    result->start_node = start;
    result->dest_node = dest;

    // Special case: start is already destination
    if (start == dest) {
        result->found = true;
        result->total_time_min = 0.0;
        result->total_distance_m = 0.0;
        result->num_expanded = 1;
        result->expanded_order[0] = start;
        result->route_length = 1;
        result->route_nodes[0] = start;
        return true;
    }

    int n = g->num_nodes;
    double* g_score = (double*)malloc(sizeof(double) * n);
    double* f_score = (double*)malloc(sizeof(double) * n);
    int* parent = (int*)malloc(sizeof(int) * n);
    bool* visited = (bool*)calloc(n, sizeof(bool));

    for (int i = 0; i < n; i++) {
        g_score[i] = DBL_MAX;
        f_score[i] = DBL_MAX;
        parent[i] = -1;
    }

    MinHeap* pq = heap_create(64);

    g_score[start] = 0.0;
    f_score[start] = graph_heuristic(g, start, dest);
    heap_push(pq, start, f_score[start]);

    bool reached = false;

    while (!heap_is_empty(pq)) {
        HeapElement elem;
        heap_pop(pq, &elem);
        int u = elem.node_id;

        // Skip if already settled in closed set
        if (visited[u]) continue;

        visited[u] = true;
        result->expanded_order[result->num_expanded++] = u;

        // Goal check: A* terminates when destination is extracted from open set
        if (u == dest) {
            reached = true;
            break;
        }

        // Explore neighbors
        Edge* edge = g->nodes[u].edges;
        while (edge) {
            int v = edge->target;
            if (!visited[v]) {
                double tentative_g = g_score[u] + edge->travel_time_min;
                if (tentative_g < g_score[v]) {
                    parent[v] = u;
                    g_score[v] = tentative_g;
                    double h = graph_heuristic(g, v, dest);
                    f_score[v] = tentative_g + h;
                    heap_push(pq, v, f_score[v]);
                }
            }
            edge = edge->next;
        }
    }

    heap_destroy(pq);

    if (reached) {
        result->found = true;
        result->total_time_min = g_score[dest];

        // Reconstruct path backward from dest to start
        int temp_path[MAX_NODES];
        int count = 0;
        int curr = dest;
        while (curr != -1) {
            temp_path[count++] = curr;
            if (curr == start) break;
            curr = parent[curr];
        }

        // Reverse into forward order
        result->route_length = count;
        for (int i = 0; i < count; i++) {
            result->route_nodes[i] = temp_path[count - 1 - i];
        }

        // Calculate total physical distance in meters along the path
        double total_dist = 0.0;
        for (int i = 0; i < result->route_length - 1; i++) {
            int u = result->route_nodes[i];
            int v = result->route_nodes[i + 1];
            Edge* e = g->nodes[u].edges;
            while (e) {
                if (e->target == v) {
                    total_dist += e->length_m;
                    break;
                }
                e = e->next;
            }
        }
        result->total_distance_m = total_dist;
    } else {
        result->found = false;
        result->total_time_min = -1.0;
        result->total_distance_m = 0.0;
        result->route_length = 0;
    }

    free(g_score);
    free(f_score);
    free(parent);
    free(visited);

    return result->found;
}
