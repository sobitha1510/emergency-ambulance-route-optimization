#!/usr/bin/env python3
"""
Emergency Ambulance Route Optimization System - Backend Server
---------------------------------------------------------------
This Python server acts as a bridge between the browser frontend
and the core C algorithm executable ('ambulance_solver').

Features:
- Serves static assets (HTML, CSS, JS, SVG icons)
- API: /api/graph -> Runs 'ambulance_solver --graph' and returns the campus graph JSON
- API: /api/route -> Runs 'ambulance_solver --algo <algo> --start <u> --dest <v>' and returns JSON
- Automatic C compilation check on startup using clang/gcc via Makefile
"""

import http.server
import socketserver
import urllib.parse
import subprocess
import os
import sys
import json

PORT = 8080
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
C_DIR = os.path.join(BASE_DIR, "c-algorithms")
SOLVER_BIN = os.path.join(C_DIR, "ambulance_solver")

def ensure_c_binary():
    """Compiles the C binary if it does not already exist."""
    if not os.path.isfile(SOLVER_BIN):
        print("[INFO] 'ambulance_solver' executable not found. Compiling C algorithms...")
        try:
            res = subprocess.run(["make", "-C", C_DIR], capture_output=True, text=True, check=True)
            print("[INFO] Compilation succeeded:\n", res.stdout)
        except subprocess.CalledProcessError as e:
            print("[ERROR] Compilation failed:\n", e.stderr)
            sys.exit(1)
    else:
        print(f"[OK] C algorithm binary ready at: {SOLVER_BIN}")

class AmbulanceBridgeHandler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=BASE_DIR, **kwargs)

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        query = urllib.parse.parse_qs(parsed.query)

        # Handle API: Get Graph
        if path == "/api/graph":
            self.handle_api_graph()
            return

        # Handle API: Solve Route
        if path == "/api/route":
            self.handle_api_route(query)
            return

        # Handle standard static files
        return super().do_GET()

    def handle_api_graph(self):
        try:
            cmd = [SOLVER_BIN, "--graph"]
            res = subprocess.run(cmd, capture_output=True, text=True, timeout=5)
            if res.returncode != 0:
                self.send_error_json(500, f"C solver failed: {res.stderr}")
                return

            self.send_json_response(json.loads(res.stdout))
        except Exception as e:
            self.send_error_json(500, f"Internal server error: {str(e)}")

    def handle_api_route(self, query):
        algo = query.get("algo", ["both"])[0]
        start = query.get("start", ["0"])[0]
        dest = query.get("dest", ["15"])[0]
        trials = query.get("trials", ["500"])[0]

        # Input validation
        if algo not in ["dijkstra", "astar", "both"]:
            self.send_error_json(400, "Invalid algorithm parameter. Choose 'dijkstra', 'astar', or 'both'.")
            return

        try:
            start_id = int(start)
            dest_id = int(dest)
        except ValueError:
            self.send_error_json(400, "Start and Dest must be valid integer node IDs.")
            return

        try:
            cmd = [
                SOLVER_BIN,
                "--algo", algo,
                "--start", str(start_id),
                "--dest", str(dest_id),
                "--trials", str(trials)
            ]
            res = subprocess.run(cmd, capture_output=True, text=True, timeout=5)
            if res.returncode != 0:
                self.send_error_json(500, f"C solver execution failed: {res.stderr}")
                return

            data = json.loads(res.stdout)
            self.send_json_response(data)
        except Exception as e:
            self.send_error_json(500, f"Error executing C algorithm: {str(e)}")

    def send_json_response(self, data, status_code=200):
        body = json.dumps(data).encode("utf-8")
        self.send_response(status_code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def send_error_json(self, status_code, message):
        payload = {"error": True, "message": message}
        self.send_json_response(payload, status_code=status_code)

def run():
    ensure_c_binary()
    server_address = ("", PORT)
    # Enable socket address reuse to avoid 'Address already in use' errors on fast restarts
    socketserver.TCPServer.allow_reuse_address = True
    with socketserver.TCPServer(server_address, AmbulanceBridgeHandler) as httpd:
        print(f"\n==================================================================")
        print(f"  Emergency Ambulance Route Optimization System is running!")
        print(f"  Localhost URL: http://localhost:{PORT}")
        print(f"  Graph API:     http://localhost:{PORT}/api/graph")
        print(f"  Route API:     http://localhost:{PORT}/api/route?algo=both&start=0&dest=15")
        print(f"==================================================================\n")
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\nShutting down server gracefully...")
            httpd.server_close()

if __name__ == "__main__":
    run()
