/**
 * Emergency Ambulance Route Optimization System
 * Frontend Controller & Interactive SVG Visualization
 * Connects directly to compiled C algorithms via Python HTTP Bridge.
 */

// Application State
const state = {
  graph: null,            // Loaded from C solver via /api/graph
  startNode: 0,           // Default: Main Entrance Gate
  destNode: 15,           // Default: University Health Care & Emergency Hospital
  currentAlgo: 'astar',   // 'dijkstra', 'astar', or 'both'
  lastResult: null,       // Result data from last execution
  comparisonResult: null, // Full comparison data
  viewMode: 'single',     // 'single' or 'dual'
  animSpeedMs: 200,       // Delay per expansion step
  isAnimating: false,
  animTimeouts: []
};

// DOM Elements
const elements = {
  startSelect: document.getElementById('startSelect'),
  destSelect: document.getElementById('destSelect'),
  btnRunBoth: document.getElementById('btnRunBoth'),
  btnRunDijkstra: document.getElementById('btnRunDijkstra'),
  btnRunAstar: document.getElementById('btnRunAstar'),
  btnResetView: document.getElementById('btnResetView'),
  btnReplayAnim: document.getElementById('btnReplayAnim'),
  animSpeedSelect: document.getElementById('animSpeedSelect'),
  singleViewBtn: document.getElementById('singleViewBtn'),
  dualViewBtn: document.getElementById('dualViewBtn'),
  singleMapWrapper: document.getElementById('singleMapWrapper'),
  dualMapWrapper: document.getElementById('dualMapWrapper'),
  mapModeBadge: document.getElementById('mapModeBadge'),
  engineStatusText: document.getElementById('engineStatusText'),
  hudStatusValue: document.getElementById('hudStatusValue'),
  hudTimeValue: document.getElementById('hudTimeValue'),
  hudNodesValue: document.getElementById('hudNodesValue'),
  currentAlgoBadge: document.getElementById('currentAlgoBadge'),
  resTravelTime: document.getElementById('resTravelTime'),
  resTravelSeconds: document.getElementById('resTravelSeconds'),
  resDistance: document.getElementById('resDistance'),
  resSpeed: document.getElementById('resSpeed'),
  resExpanded: document.getElementById('resExpanded'),
  resExpandedRatio: document.getElementById('resExpandedRatio'),
  resExecTime: document.getElementById('resExecTime'),
  routeBreadcrumbs: document.getElementById('routeBreadcrumbs'),
  expansionTrace: document.getElementById('expansionTrace'),
  compDijkstraTime: document.getElementById('compDijkstraTime'),
  compAstarTime: document.getElementById('compAstarTime'),
  compTimeMatch: document.getElementById('compTimeMatch'),
  compDijkstraExpanded: document.getElementById('compDijkstraExpanded'),
  compAstarExpanded: document.getElementById('compAstarExpanded'),
  compExpandedDiff: document.getElementById('compExpandedDiff'),
  compEfficiency: document.getElementById('compEfficiency'),
  compDijkstraHops: document.getElementById('compDijkstraHops'),
  compAstarHops: document.getElementById('compAstarHops'),
  compDijkstraExec: document.getElementById('compDijkstraExec'),
  compAstarExec: document.getElementById('compAstarExec'),
  dijkstraBar: document.getElementById('dijkstraBar'),
  dijkstraBarVal: document.getElementById('dijkstraBarVal'),
  astarBar: document.getElementById('astarBar'),
  astarBarVal: document.getElementById('astarBarVal'),
  dijkstraCounter: document.getElementById('dijkstraCounter'),
  astarCounter: document.getElementById('astarCounter')
};

// ============================================================================
// Initialization & Graph Loading
// ============================================================================

document.addEventListener('DOMContentLoaded', async () => {
  setupEventListeners();
  await loadCampusGraph();
});

function setupEventListeners() {
  elements.startSelect.addEventListener('change', (e) => {
    state.startNode = parseInt(e.target.value, 10);
    renderMapState();
  });

  elements.destSelect.addEventListener('change', (e) => {
    state.destNode = parseInt(e.target.value, 10);
    renderMapState();
  });

  elements.btnRunBoth.addEventListener('click', () => runAlgorithm('both'));
  elements.btnRunDijkstra.addEventListener('click', () => runAlgorithm('dijkstra'));
  elements.btnRunAstar.addEventListener('click', () => runAlgorithm('astar'));
  elements.btnResetView.addEventListener('click', resetVisualization);
  elements.btnReplayAnim.addEventListener('click', replayAnimation);

  elements.animSpeedSelect.addEventListener('change', (e) => {
    state.animSpeedMs = parseInt(e.target.value, 10);
  });

  // Preset Scenario Chips
  document.querySelectorAll('.chip-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.chip-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const start = parseInt(btn.dataset.start, 10);
      const dest = parseInt(btn.dataset.dest, 10);
      state.startNode = start;
      state.destNode = dest;
      elements.startSelect.value = start;
      elements.destSelect.value = dest;
      renderMapState();
      runAlgorithm('both');
    });
  });

  // View Mode Switcher
  elements.singleViewBtn.addEventListener('click', () => setViewMode('single'));
  elements.dualViewBtn.addEventListener('click', () => setViewMode('dual'));
}

async function loadCampusGraph() {
  try {
    elements.engineStatusText.textContent = "Connecting to C Engine...";
    const res = await fetch('/api/graph');
    if (!res.ok) throw new Error(`HTTP ${res.status}: Failed to fetch graph`);
    state.graph = await res.json();

    elements.engineStatusText.textContent = "Online (Clang C99 Min-Heap Engine)";
    populateDropdowns();
    renderCampusMap('campusSvg', state.graph);
    renderCampusMap('svgDijkstraDual', state.graph, 'dijkstra');
    renderCampusMap('svgAstarDual', state.graph, 'astar');
    renderMapState();

    // Run initial benchmark demonstration
    await runAlgorithm('both');
  } catch (err) {
    console.error("Failed to load campus graph:", err);
    elements.engineStatusText.textContent = "Error: Check Python server & C binary";
    elements.engineStatusText.style.color = "var(--accent-red)";
  }
}

function populateDropdowns() {
  elements.startSelect.innerHTML = '';
  elements.destSelect.innerHTML = '';

  state.graph.nodes.forEach(node => {
    const optStart = document.createElement('option');
    optStart.value = node.id;
    optStart.textContent = `[${node.code}] ${node.name} (${node.category})`;
    if (node.id === state.startNode) optStart.selected = true;
    elements.startSelect.appendChild(optStart);

    const optDest = document.createElement('option');
    optDest.value = node.id;
    optDest.textContent = `[${node.code}] ${node.name} (${node.category})`;
    if (node.id === state.destNode) optDest.selected = true;
    elements.destSelect.appendChild(optDest);
  });
}

function setViewMode(mode) {
  state.viewMode = mode;
  if (mode === 'single') {
    elements.singleViewBtn.classList.add('active');
    elements.dualViewBtn.classList.remove('active');
    elements.singleMapWrapper.style.display = 'flex';
    elements.dualMapWrapper.style.display = 'none';
  } else {
    elements.singleViewBtn.classList.remove('active');
    elements.dualViewBtn.classList.add('active');
    elements.singleMapWrapper.style.display = 'none';
    elements.dualMapWrapper.style.display = 'grid';
    // If we have comparison result, render both dual maps
    if (state.comparisonResult) {
      animateDualMaps(state.comparisonResult);
    }
  }
}

// ============================================================================
// SVG Campus Map Renderer
// ============================================================================

function renderCampusMap(svgId, graph, variant = 'standard') {
  const svg = document.getElementById(svgId);
  if (!svg || !graph) return;

  // Clear previous layers except defs
  const defs = svg.querySelector('defs');
  svg.innerHTML = '';
  if (defs) svg.appendChild(defs);

  // Background Campus Zones (SRM AP landscape representation)
  const bgGroup = document.createElementNS('http://www.w3.org/2000/svg', 'g');
  bgGroup.setAttribute('id', `${svgId}_bg`);
  bgGroup.innerHTML = `
    <!-- Grid ground pattern -->
    <rect width="1000" height="700" fill="#090E17" />
    <!-- Campus Green Lawn Quadrangle -->
    <rect x="360" y="240" width="280" height="190" rx="20" fill="rgba(16, 185, 129, 0.04)" stroke="rgba(16, 185, 129, 0.12)" stroke-width="1.5" />
    <text x="500" y="340" fill="rgba(16, 185, 129, 0.25)" font-size="12" font-weight="700" text-anchor="middle" letter-spacing="2">ACADEMIC QUADRANGLE</text>
    <!-- Residential Quadrangle -->
    <rect x="740" y="280" width="180" height="230" rx="16" fill="rgba(56, 189, 248, 0.03)" stroke="rgba(56, 189, 248, 0.1)" stroke-width="1.5" />
    <text x="830" y="390" fill="rgba(56, 189, 248, 0.25)" font-size="11" font-weight="700" text-anchor="middle" letter-spacing="1">HOSTEL SECTOR</text>
    <!-- Sports Field Oval -->
    <ellipse cx="720" cy="605" rx="140" ry="40" fill="rgba(245, 158, 11, 0.03)" stroke="rgba(245, 158, 11, 0.15)" stroke-width="1.5" stroke-dasharray="6 4" />
    <text x="720" y="610" fill="rgba(245, 158, 11, 0.25)" font-size="10" font-weight="700" text-anchor="middle" letter-spacing="1">ATHLETIC ARENA</text>
    <!-- Medical Care Zone -->
    <rect x="380" y="40" width="200" height="80" rx="14" fill="rgba(239, 68, 68, 0.05)" stroke="rgba(239, 68, 68, 0.2)" stroke-width="1.5" />
    <text x="480" y="58" fill="rgba(239, 68, 68, 0.5)" font-size="9" font-weight="800" text-anchor="middle" letter-spacing="1.5">EMERGENCY MEDICAL ZONE</text>
  `;
  svg.appendChild(bgGroup);

  // Roads Group
  const roadsGroup = document.createElementNS('http://www.w3.org/2000/svg', 'g');
  roadsGroup.setAttribute('id', `${svgId}_roads`);

  graph.edges.forEach(edge => {
    const uNode = graph.nodes[edge.u];
    const vNode = graph.nodes[edge.v];
    if (!uNode || !vNode) return;

    // Asphalt Base
    const roadLine = document.createElementNS('http://www.w3.org/2000/svg', 'line');
    roadLine.setAttribute('x1', uNode.x);
    roadLine.setAttribute('y1', uNode.y);
    roadLine.setAttribute('x2', vNode.x);
    roadLine.setAttribute('y2', vNode.y);
    roadLine.setAttribute('class', 'road-line');
    roadLine.setAttribute('data-u', edge.u);
    roadLine.setAttribute('data-v', edge.v);
    roadsGroup.appendChild(roadLine);

    // Center Dashed Lane
    const centerLine = document.createElementNS('http://www.w3.org/2000/svg', 'line');
    centerLine.setAttribute('x1', uNode.x);
    centerLine.setAttribute('y1', uNode.y);
    centerLine.setAttribute('x2', vNode.x);
    centerLine.setAttribute('y2', vNode.y);
    centerLine.setAttribute('class', 'road-centerline');
    roadsGroup.appendChild(centerLine);

    // Midpoint road distance and speed label (subtle)
    const midX = (uNode.x + vNode.x) / 2;
    const midY = (uNode.y + vNode.y) / 2;
    const roadText = document.createElementNS('http://www.w3.org/2000/svg', 'text');
    roadText.setAttribute('x', midX);
    roadText.setAttribute('y', midY - 6);
    roadText.setAttribute('class', 'road-label');
    roadText.setAttribute('text-anchor', 'middle');
    roadText.textContent = `${edge.length_m.toFixed(0)}m (${edge.speed_kmh}km/h)`;
    roadsGroup.appendChild(roadText);
  });
  svg.appendChild(roadsGroup);

  // Exploration Layer (Dynamic)
  const expGroup = document.createElementNS('http://www.w3.org/2000/svg', 'g');
  expGroup.setAttribute('id', `${svgId}_exploration`);
  svg.appendChild(expGroup);

  // Optimal Route Layer (Dynamic)
  const routeGroup = document.createElementNS('http://www.w3.org/2000/svg', 'g');
  routeGroup.setAttribute('id', `${svgId}_route`);
  svg.appendChild(routeGroup);

  // Nodes Group
  const nodesGroup = document.createElementNS('http://www.w3.org/2000/svg', 'g');
  nodesGroup.setAttribute('id', `${svgId}_nodes`);

  graph.nodes.forEach(node => {
    const g = document.createElementNS('http://www.w3.org/2000/svg', 'g');
    g.setAttribute('class', 'node-group');
    g.setAttribute('data-node-id', node.id);
    g.setAttribute('transform', `translate(${node.x}, ${node.y})`);

    // Node outer circle
    const circle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
    circle.setAttribute('r', '16');
    circle.setAttribute('class', 'node-circle');
    circle.setAttribute('id', `${svgId}_node_circle_${node.id}`);
    g.appendChild(circle);

    // Node short code
    const text = document.createElementNS('http://www.w3.org/2000/svg', 'text');
    text.setAttribute('y', '4');
    text.setAttribute('class', 'node-text');
    text.setAttribute('id', `${svgId}_node_text_${node.id}`);
    text.textContent = node.code;
    g.appendChild(text);

    // Label below node
    const desc = document.createElementNS('http://www.w3.org/2000/svg', 'text');
    desc.setAttribute('y', '27');
    desc.setAttribute('class', 'node-desc');
    desc.textContent = node.name;
    g.appendChild(desc);

    // Click on node sets as Start (left click) or Dest (with shift key)
    g.addEventListener('click', (e) => {
      if (e.shiftKey) {
        state.destNode = node.id;
        elements.destSelect.value = node.id;
      } else {
        state.startNode = node.id;
        elements.startSelect.value = node.id;
      }
      renderMapState();
      runAlgorithm(state.currentAlgo);
    });

    nodesGroup.appendChild(g);
  });
  svg.appendChild(nodesGroup);

  // Actor / Ambulance Layer
  const actorGroup = document.createElementNS('http://www.w3.org/2000/svg', 'g');
  actorGroup.setAttribute('id', `${svgId}_actor`);
  actorGroup.innerHTML = `
    <g id="${svgId}_ambulance" class="ambulance-actor" style="display: none;">
      <circle r="20" fill="rgba(239, 68, 68, 0.2)" class="pulse-beacon" />
      <circle r="13" fill="#EF4444" stroke="#FFFFFF" stroke-width="2" />
      <text x="0" y="4" text-anchor="middle" font-size="12">🚑</text>
    </g>
  `;
  svg.appendChild(actorGroup);
}

// ============================================================================
// State & Marker Synchronization
// ============================================================================

function renderMapState() {
  updateNodeMarkers('campusSvg');
  updateNodeMarkers('svgDijkstraDual');
  updateNodeMarkers('svgAstarDual');
}

function updateNodeMarkers(svgId) {
  if (!state.graph) return;

  state.graph.nodes.forEach(node => {
    const circle = document.getElementById(`${svgId}_node_circle_${node.id}`);
    if (!circle) return;

    // Reset base classes
    circle.className.baseVal = 'node-circle';

    if (node.id === state.startNode) {
      circle.classList.add('start-node');
    } else if (node.id === state.destNode) {
      circle.classList.add('hospital-node');
    }
  });

  // Place ambulance sprite initially at start node
  const amb = document.getElementById(`${svgId}_ambulance`);
  const startNodeObj = state.graph.nodes[state.startNode];
  if (amb && startNodeObj) {
    amb.style.display = 'block';
    amb.setAttribute('transform', `translate(${startNodeObj.x}, ${startNodeObj.y})`);
  }
}

// ============================================================================
// Algorithm Execution & C Backend Communication
// ============================================================================

async function runAlgorithm(algo = 'both') {
  clearActiveAnimations();
  state.currentAlgo = algo;

  const start = state.startNode;
  const dest = state.destNode;

  elements.hudStatusValue.textContent = "Computing with C...";

  // Check if start == dest edge case
  if (start === dest) {
    elements.hudStatusValue.textContent = "Start = Dest (0 min)";
    elements.resTravelTime.textContent = "0.00 min";
    elements.resTravelSeconds.textContent = "0 seconds";
    elements.resDistance.textContent = "0 m";
    elements.resSpeed.textContent = "At Destination";
    elements.resExpanded.textContent = "1";
    elements.resExpandedRatio.textContent = "1 / 16 total nodes";
    elements.resExecTime.textContent = "0.02 μs";
    elements.routeBreadcrumbs.innerHTML = `<span class="crumb-node start dest">${state.graph.nodes[start].name} (Already at Hospital)</span>`;
    elements.expansionTrace.innerHTML = `<span class="trace-item active">[${state.graph.nodes[start].code}]</span>`;
    return;
  }

  try {
    const url = `/api/route?algo=${algo}&start=${start}&dest=${dest}&trials=500`;
    const res = await fetch(url);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();

    if (algo === 'both') {
      state.comparisonResult = data;
      state.lastResult = data.astar; // Default single view display to A*
      elements.mapModeBadge.textContent = "Comparison Mode (Dijkstra vs A*)";
      updateComparisonDashboard(data);
      updateMetricsDashboard(data.astar, "A* Search");

      if (state.viewMode === 'dual') {
        animateDualMaps(data);
      } else {
        animateSingleMap(data.astar, 'astar');
      }
    } else if (algo === 'dijkstra') {
      state.lastResult = data;
      elements.mapModeBadge.textContent = "Active: Dijkstra’s Algorithm";
      updateMetricsDashboard(data, "Dijkstra");
      animateSingleMap(data, 'dijkstra');
    } else {
      state.lastResult = data;
      elements.mapModeBadge.textContent = "Active: A* Search Algorithm";
      updateMetricsDashboard(data, "A* Search");
      animateSingleMap(data, 'astar');
    }

    elements.hudStatusValue.textContent = "Optimized";
  } catch (err) {
    console.error("Execution failed:", err);
    elements.hudStatusValue.textContent = "C Execution Error";
  }
}

// ============================================================================
// Metrics & Dashboard Updates
// ============================================================================

function updateMetricsDashboard(res, algoLabel) {
  elements.currentAlgoBadge.textContent = algoLabel;
  elements.currentAlgoBadge.className = `algo-badge ${algoLabel.includes('Dijkstra') ? 'dijkstra' : 'astar'}`;

  const minutes = res.total_time_min;
  const seconds = (minutes * 60).toFixed(1);
  elements.resTravelTime.textContent = `${minutes.toFixed(2)} min`;
  elements.resTravelSeconds.textContent = `${seconds}s total`;

  elements.resDistance.textContent = `${res.total_distance_m.toFixed(0)} m`;
  const avgSpeedKmh = minutes > 0 ? ((res.total_distance_m / 1000) / (minutes / 60)).toFixed(1) : 0;
  elements.resSpeed.textContent = `Avg Speed: ${avgSpeedKmh} km/h`;

  elements.resExpanded.textContent = res.num_expanded;
  elements.resExpandedRatio.textContent = `${res.num_expanded} / ${state.graph.nodes.length} campus nodes`;
  elements.resExecTime.textContent = `${res.execution_time_us.toFixed(2)} μs`;

  elements.hudTimeValue.textContent = `${minutes.toFixed(2)} min`;
  elements.hudNodesValue.textContent = `${res.num_expanded} / 16`;

  // Update Route Sequence Breadcrumbs
  elements.routeBreadcrumbs.innerHTML = '';
  res.route_nodes.forEach((nodeId, idx) => {
    const node = state.graph.nodes[nodeId];
    const crumb = document.createElement('span');
    crumb.className = `crumb-node ${idx === 0 ? 'start' : ''} ${idx === res.route_nodes.length - 1 ? 'dest' : ''}`;
    crumb.textContent = `[${node.code}] ${node.name}`;
    elements.routeBreadcrumbs.appendChild(crumb);

    if (idx < res.route_nodes.length - 1) {
      const arrow = document.createElement('span');
      arrow.className = 'crumb-arrow';
      arrow.textContent = '➔';
      elements.routeBreadcrumbs.appendChild(arrow);
    }
  });

  // Update Expansion Trace
  elements.expansionTrace.innerHTML = '';
  res.expanded_order.forEach((nodeId, idx) => {
    const node = state.graph.nodes[nodeId];
    const trace = document.createElement('span');
    trace.className = 'trace-item';
    trace.id = `trace_step_${idx}`;
    trace.textContent = `${idx + 1}.${node.code}`;
    elements.expansionTrace.appendChild(trace);
  });
}

function updateComparisonDashboard(comp) {
  const d = comp.dijkstra;
  const a = comp.astar;
  const c = comp.comparison;

  // Total Travel Times (Identical for optimal search)
  elements.compDijkstraTime.textContent = `${d.total_time_min.toFixed(4)} min`;
  elements.compAstarTime.textContent = `${a.total_time_min.toFixed(4)} min`;
  elements.compTimeMatch.textContent = c.optimal_travel_time_match ? "✓ Exact Match" : "Differs";

  // Expanded Nodes Comparison
  elements.compDijkstraExpanded.textContent = `${d.num_expanded} nodes`;
  elements.compAstarExpanded.textContent = `${a.num_expanded} nodes`;
  elements.compExpandedDiff.textContent = `${c.expanded_difference} nodes saved (${c.expanded_reduction_pct.toFixed(1)}%)`;

  // Search Effort Efficiency
  elements.compEfficiency.textContent = `${(100 - c.expanded_reduction_pct).toFixed(1)}% of Dijkstra`;

  // Route lengths
  elements.compDijkstraHops.textContent = `${d.total_distance_m.toFixed(0)}m (${d.route_nodes.length} nodes)`;
  elements.compAstarHops.textContent = `${a.total_distance_m.toFixed(0)}m (${a.route_nodes.length} nodes)`;

  // Execution Times
  elements.compDijkstraExec.textContent = `${d.execution_time_us.toFixed(2)} μs`;
  elements.compAstarExec.textContent = `${a.execution_time_us.toFixed(2)} μs`;

  // Bar Chart Updates
  const maxNodes = state.graph.nodes.length;
  const dPct = (d.num_expanded / maxNodes) * 100;
  const aPct = (a.num_expanded / maxNodes) * 100;

  elements.dijkstraBar.style.width = `${Math.max(dPct, 15)}%`;
  elements.dijkstraBarVal.textContent = `${d.num_expanded} nodes (${dPct.toFixed(0)}%)`;

  elements.astarBar.style.width = `${Math.max(aPct, 15)}%`;
  elements.astarBarVal.textContent = `${a.num_expanded} nodes (${aPct.toFixed(0)}%)`;
}

// ============================================================================
// Visual Animation Engine
// ============================================================================

function clearActiveAnimations() {
  state.animTimeouts.forEach(t => clearTimeout(t));
  state.animTimeouts = [];
  state.isAnimating = false;

  // Clear visual overlays on all SVGs
  ['campusSvg', 'svgDijkstraDual', 'svgAstarDual'].forEach(id => {
    const exp = document.getElementById(`${id}_exploration`);
    const rt = document.getElementById(`${id}_route`);
    if (exp) exp.innerHTML = '';
    if (rt) rt.innerHTML = '';
  });
  renderMapState();
}

function animateSingleMap(result, algoType = 'astar') {
  clearActiveAnimations();
  state.isAnimating = true;

  const svgId = 'campusSvg';
  const expLayer = document.getElementById(`${svgId}_exploration`);
  const routeLayer = document.getElementById(`${svgId}_route`);
  const amb = document.getElementById(`${svgId}_ambulance`);

  const speed = state.animSpeedMs;

  // Step 1: Sequential Node Expansion Animation
  result.expanded_order.forEach((nodeId, idx) => {
    const t = setTimeout(() => {
      const node = state.graph.nodes[nodeId];
      if (!node) return;

      // Color node circle
      const circle = document.getElementById(`${svgId}_node_circle_${nodeId}`);
      if (circle && nodeId !== state.startNode && nodeId !== state.destNode) {
        circle.classList.add(algoType === 'dijkstra' ? 'explored-dijkstra' : 'explored-astar');
      }

      // Radar pulse wave
      const wave = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
      wave.setAttribute('cx', node.x);
      wave.setAttribute('cy', node.y);
      wave.setAttribute('class', `exploration-wave ${algoType}`);
      expLayer.appendChild(wave);

      // Highlight step in expansion trace
      const traceItem = document.getElementById(`trace_step_${idx}`);
      if (traceItem) traceItem.classList.add('active');

      elements.hudNodesValue.textContent = `${idx + 1} / ${state.graph.nodes.length}`;
    }, idx * speed);

    state.animTimeouts.push(t);
  });

  // Step 2: Draw Final Optimal Route
  const routeStartTime = result.expanded_order.length * speed + 100;
  const routeTimer = setTimeout(() => {
    drawOptimalRoute(svgId, result.route_nodes);
    // Step 3: Animate Ambulance Vehicle
    animateAmbulanceDrive(svgId, result.route_nodes);
  }, routeStartTime);
  state.animTimeouts.push(routeTimer);
}

function animateDualMaps(comp) {
  clearActiveAnimations();
  state.isAnimating = true;

  const speed = state.animSpeedMs;

  // Animate Dijkstra (Left Pane)
  comp.dijkstra.expanded_order.forEach((nodeId, idx) => {
    const t = setTimeout(() => {
      const node = state.graph.nodes[nodeId];
      const circle = document.getElementById(`svgDijkstraDual_node_circle_${nodeId}`);
      if (circle && nodeId !== state.startNode && nodeId !== state.destNode) {
        circle.classList.add('explored-dijkstra');
      }
      elements.dijkstraCounter.textContent = `Nodes: ${idx + 1}`;
    }, idx * speed);
    state.animTimeouts.push(t);
  });

  const dijkstraFinishTime = comp.dijkstra.expanded_order.length * speed + 100;
  const tDijkstraRoute = setTimeout(() => {
    drawOptimalRoute('svgDijkstraDual', comp.dijkstra.route_nodes);
    animateAmbulanceDrive('svgDijkstraDual', comp.dijkstra.route_nodes);
  }, dijkstraFinishTime);
  state.animTimeouts.push(tDijkstraRoute);

  // Animate A* (Right Pane)
  comp.astar.expanded_order.forEach((nodeId, idx) => {
    const t = setTimeout(() => {
      const node = state.graph.nodes[nodeId];
      const circle = document.getElementById(`svgAstarDual_node_circle_${nodeId}`);
      if (circle && nodeId !== state.startNode && nodeId !== state.destNode) {
        circle.classList.add('explored-astar');
      }
      elements.astarCounter.textContent = `Nodes: ${idx + 1}`;
    }, idx * speed);
    state.animTimeouts.push(t);
  });

  const astarFinishTime = comp.astar.expanded_order.length * speed + 100;
  const tAstarRoute = setTimeout(() => {
    drawOptimalRoute('svgAstarDual', comp.astar.route_nodes);
    animateAmbulanceDrive('svgAstarDual', comp.astar.route_nodes);
  }, astarFinishTime);
  state.animTimeouts.push(tAstarRoute);
}

function drawOptimalRoute(svgId, routeNodes) {
  const routeLayer = document.getElementById(`${svgId}_route`);
  if (!routeLayer || !routeNodes || routeNodes.length < 2) return;

  routeLayer.innerHTML = '';

  // Build SVG path string along route
  let d = '';
  for (let i = 0; i < routeNodes.length; i++) {
    const node = state.graph.nodes[routeNodes[i]];
    d += (i === 0 ? `M ${node.x} ${node.y}` : ` L ${node.x} ${node.y}`);
  }

  // Under-glow line
  const glowLine = document.createElementNS('http://www.w3.org/2000/svg', 'path');
  glowLine.setAttribute('d', d);
  glowLine.setAttribute('class', 'route-edge-glow');
  routeLayer.appendChild(glowLine);

  // Core animated path
  const pathLine = document.createElementNS('http://www.w3.org/2000/svg', 'path');
  pathLine.setAttribute('d', d);
  pathLine.setAttribute('class', 'route-path-line');
  routeLayer.appendChild(pathLine);
}

function animateAmbulanceDrive(svgId, routeNodes) {
  const amb = document.getElementById(`${svgId}_ambulance`);
  if (!amb || !routeNodes || routeNodes.length === 0) return;

  amb.style.display = 'block';

  // Smooth interpolation along route coordinates
  const waypoints = routeNodes.map(id => state.graph.nodes[id]);
  let currentLeg = 0;
  let progress = 0.0;
  const legSteps = 24;

  function step() {
    if (currentLeg >= waypoints.length - 1) {
      // Arrived at destination
      const dest = waypoints[waypoints.length - 1];
      amb.setAttribute('transform', `translate(${dest.x}, ${dest.y})`);
      state.isAnimating = false;
      return;
    }

    const p1 = waypoints[currentLeg];
    const p2 = waypoints[currentLeg + 1];

    progress += 1.0 / legSteps;
    if (progress >= 1.0) {
      progress = 0.0;
      currentLeg++;
    }

    const currX = p1.x + (p2.x - p1.x) * progress;
    const currY = p1.y + (p2.y - p1.y) * progress;

    amb.setAttribute('transform', `translate(${currX}, ${currY})`);
    requestAnimationFrame(step);
  }

  requestAnimationFrame(step);
}

function resetVisualization() {
  clearActiveAnimations();
  renderMapState();
  elements.hudStatusValue.textContent = "Ready";
  elements.hudTimeValue.textContent = "-- min";
  elements.hudNodesValue.textContent = "-- / 16";
  elements.routeBreadcrumbs.innerHTML = '<span class="placeholder-text">Run an algorithm to calculate route</span>';
  elements.expansionTrace.innerHTML = '<span class="placeholder-text">No active search trace</span>';
}

function replayAnimation() {
  if (state.lastResult) {
    if (state.comparisonResult && state.viewMode === 'dual') {
      animateDualMaps(state.comparisonResult);
    } else {
      animateSingleMap(state.lastResult, state.currentAlgo);
    }
  }
}
