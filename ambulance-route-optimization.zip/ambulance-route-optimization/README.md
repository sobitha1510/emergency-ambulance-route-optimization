# Emergency Ambulance Route Optimization System
### Comparing Dijkstra’s Algorithm and A* Search for Emergency Medical Dispatch
**Simulated SRM University AP (Andhra Pradesh) Campus Road Network**

---

## 1. Project Overview

The **Emergency Ambulance Route Optimization System** is an interactive, full-stack educational simulation designed to model emergency ambulance dispatch across a university campus road network. 

In medical emergencies, every fraction of a minute matters. Traditional shortest-path routing often optimizes for geometric distance rather than actual travel time, which can lead to suboptimal choices when roads have different speed limits. This system:
- Models a simulated campus road network inspired by **SRM University AP** with 16 realistic intersections and landmarks.
- Computes the minimum-travel-time route using **Dijkstra’s Algorithm** and **A* Search Algorithm**.
- Genuinely implements both graph algorithms in **ANSI C (C99)** using an indexed binary **Min-Heap Priority Queue**.
- Uses an **admissible straight-line travel-time heuristic** for A*, proving mathematically that A* finds the identical optimal travel time while exploring fewer nodes.
- Bridges the native C algorithms to a modern web dashboard with step-by-step exploration animations, glowing route visualizations, an animated ambulance sprite, and real-time comparison tables and bar charts.

---

## 2. Technologies Used

- **C (C99):** Core algorithmic engine implementing graph data structures, min-heap priority queues, Dijkstra’s algorithm, and A* search.
- **Python 3 (`http.server` & `subprocess`):** Zero-dependency native HTTP bridge that executes the compiled C binary and serves the web frontend.
- **HTML5:** Semantic dashboard structure, HUD display, and control panels.
- **CSS3:** Modern dark glassmorphism theme, responsive grid, dynamic bar charts, and keyframe animations.
- **JavaScript (ES6+):** Frontend interaction handling, dynamic SVG manipulation, animation loops, and asynchronous C API polling.
- **SVG (Scalable Vector Graphics):** High-definition campus landscape, road network, landmark nodes, pulsing exploration radar waves, and route path glow.

---

## 3. Graph Representation & Travel-Time Modeling

The campus road network is modeled as a weighted, undirected graph $G = (V, E)$:
- **Vertices ($V$):** 16 campus landmarks/intersections, each with 2D Cartesian coordinates $(x, y)$ in meters.
- **Edges ($E$):** 25 bidirectional road segments connecting adjacent landmarks.

### Travel-Time Calculation
Unlike textbook examples that assign arbitrary unitless weights, our edge weights represent **travel time in minutes**:
$$\text{Travel Time } t_e = \frac{\text{Road Length } L_e \text{ (meters)}}{\text{Speed Limit } v_e \text{ (meters/minute)}}$$

Since road speed limits are specified in $\text{km/h}$:
$$v_e \text{ (m/min)} = v_e \text{ (km/h)} \times \frac{1000 \text{ meters}}{60 \text{ minutes}} = \frac{v_e \times 1000}{60}$$

Substituting into the travel time formula:
$$t_e = \frac{L_e \times 60}{v_e \times 1000} \text{ (minutes)}$$

### Campus Landmarks (Nodes)
| Node ID | Code | Landmark Name | Category | Coordinates $(x, y)$ |
|:---:|:---:|:---|:---:|:---:|
| 0 | `GATE` | Main Entrance Gate | Entrance | $(80, 350)$ |
| 1 | `SEC` | Security Roundabout & Welcome Bay | Facility | $(200, 350)$ |
| 2 | `PARK` | West Parking & Transit Bus Bay | Facility | $(180, 530)$ |
| 3 | `ADMIN` | Admin Block (Subhash Chandra Bose) | Academic | $(340, 320)$ |
| 4 | `MECH` | Mechanical & Robotics Workshops | Academic | $(320, 530)$ |
| 5 | `ACAD1` | Academic Block 1 (Lecture Theatres) | Academic | $(480, 220)$ |
| 6 | `ACAD2` | Academic Block 2 (Computing Labs) | Academic | $(520, 360)$ |
| 7 | `LIB` | Central Library & Knowledge Hub | Academic | $(400, 450)$ |
| 8 | `SAC` | Student Activity Centre (Auditorium) | Amenity | $(650, 220)$ |
| 9 | `MESS` | Central Dining & Rock Plaza | Amenity | $(620, 440)$ |
| 10 | `SPORTS`| Indoor Sports Complex & Gym | Sports | $(620, 600)$ |
| 11 | `TRACK` | Athletic Track & Sports Arena | Sports | $(820, 610)$ |
| 12 | `HOST_B`| Ganga-Godavari Boys Hostel Complex | Hostel | $(840, 460)$ |
| 13 | `HOST_G`| Narmada-Yamuna Girls Hostel Complex| Hostel | $(840, 310)$ |
| 14 | `FACULTY`| Faculty Enclave & Guest House | Residential | $(800, 160)$ |
| 15 | `HOSP` | University Health Care & Emergency | Medical | $(480, 70)$ |

---

## 4. Dijkstra’s Algorithm in C

Dijkstra’s algorithm computes the shortest path from a starting node to all other nodes (or until destination is settled) by iteratively selecting the unvisited node with the smallest known distance.

### Implementation Details (`dijkstra.c`):
1. **Distance Array (`dist[]`):** Initialized to $\infty$ (`DBL_MAX`), with `dist[start] = 0.0`.
2. **Min-Heap Priority Queue:** Stores `(node_id, dist[node_id])`.
3. **Parent Array (`parent[]`):** Maintains predecessor pointers to reconstruct the exact path.
4. **Visited Array (`visited[]`):** Tracks settled nodes.
5. **Node Expansion Recording:** Every time a node $u$ is extracted from the min-heap and its outgoing edges are relaxed, it is recorded in `expanded_order[]`.
6. **Early Goal Stopping:** As soon as the hospital node is popped from the min-heap, Dijkstra terminates, saving redundant search steps.

---

## 5. A* Search Algorithm & Admissible Heuristic in C

A* Search enhances Dijkstra’s algorithm by incorporating a directional heuristic $h(n)$ estimating the remaining cost to the destination:
$$f(n) = g(n) + h(n)$$
- $g(n)$: Exact shortest travel time from start node to node $n$.
- $h(n)$: Estimated travel time from node $n$ to destination hospital.
- $f(n)$: Estimated total travel time through node $n$.

### Mathematical Proof of Admissibility
For A* to guarantee finding an optimal route, the heuristic function $h(n)$ must be **admissible** (it must never overestimate the true remaining cost).

Because our edge weights represent **travel time in minutes**, raw Euclidean distance cannot be used as $h(n)$. Instead:
$$h(n) = \frac{\text{Straight-Line Euclidean Distance}(n, \text{Hospital})}{\text{Maximum Campus Road Speed } (V_{\max})}$$

In our campus network:
- Maximum speed limit across all roads is $V_{\max} = 40.0 \text{ km/h} \approx 666.67 \text{ m/min}$.
- Every road segment's physical length $L_e \ge \text{Euclidean Distance}$.
- Every road segment's speed $v_e \le V_{\max}$.

Therefore:
$$\text{Actual travel time on any road } t_e = \frac{L_e}{v_e} \ge \frac{\text{Euclidean Distance}}{V_{\max}} = h(n)$$

By mathematical induction along any path, $h(n) \le \text{true minimum remaining travel time}$. 

**Conclusion:** 
1. The heuristic is **admissible** and **consistent (monotonic)**.
2. A* is mathematically guaranteed to find the **exact same optimal travel time as Dijkstra**.
3. A* guides the priority queue frontier directly towards the hospital, ignoring nodes in opposite directions and **expanding significantly fewer nodes**.

---

## 6. How the C Code Communicates with the Frontend

```
+-------------------------------------------------------------+
| Browser Frontend (HTML5 / CSS3 / JavaScript / SVG)           |
| - Interactive Map, Selectors, Comparison Table, Bar Chart    |
+-------------------------------------------------------------+
                             ▲
                             │ HTTP JSON API (fetch)
                             ▼
+-------------------------------------------------------------+
| Python HTTP Bridge (server.py)                              |
| - Port 8080                                                 |
| - Serves static files                                       |
| - Executes C binary via subprocess                          |
+-------------------------------------------------------------+
                             ▲
                             │ Standard Input / CLI Flags
                             ▼
+-------------------------------------------------------------+
| Native C Engine (ambulance_solver)                          |
| - Compiled with clang -O2                                   |
| - graph.c, heap.c, dijkstra.c, astar.c, main.c             |
| - Returns pure JSON to stdout                               |
+-------------------------------------------------------------+
```

1. The frontend initiates `fetch('/api/route?algo=both&start=12&dest=15&trials=500')`.
2. `server.py` receives the request and runs `./c-algorithms/ambulance_solver --algo both --start 12 --dest 15 --trials 500`.
3. The C binary executes both Dijkstra and A*, performs high-resolution microsecond benchmarking, and formats the output as clean JSON to `stdout`.
4. `server.py` captures the stdout and streams it back to the browser as `application/json`.
5. JavaScript parses the real C results and drives the SVG radar pulse waves, route glow lines, and vehicle drive animations.

---

## 7. Execution Commands

### Prerequisites
- macOS or Linux with `clang` or `gcc` installed.
- Python 3 (3.8 or higher, standard on macOS/Linux).

### Step 1: Open Terminal and Navigate to Directory
```bash
cd /Users/raja/.gemini/antigravity/scratch/ambulance-route-optimization
```

### Step 2: Compile the C Binary (Manual or Automatic)
You can compile manually using `make`:
```bash
cd c-algorithms
make
cd ..
```
*(Note: If you run `python3 server.py`, it will automatically detect and compile the C code for you if not already built!)*

### Step 3: Start the System
```bash
python3 server.py
```

### Step 4: Open in Web Browser
Open your browser and navigate to:
```
http://localhost:8080
```

---

## 8. How to Demonstrate to Your Professor (Viva Guide)

When presenting this project to your college professor, follow these 4 steps:

### Demonstration Flow:
1. **Show the Simulated Campus Map:**
   - Point out the 16 campus locations inspired by SRM University AP.
   - Mention that roads have distinct physical lengths ($m$) and speed limits ($25\text{--}40 \text{ km/h}$), meaning shortest distance is not always quickest time!
2. **Click "Boys Hostel $\rightarrow$ Hospital" Preset:**
   - Click the preset button or select Start: `Node 12 (Ganga-Godavari Boys Hostel)` and Dest: `Node 15 (Hospital)`.
   - Click **"Compare Both Algorithms"**.
3. **Highlight the Key Results in the Table:**
   - **Optimal Travel Time:** Show that both Dijkstra and A* return the **exact same travel time** (`1.1421 minutes` = `68.5 seconds`). This proves that A* does not sacrifice accuracy.
   - **Nodes Expanded:** Point out that Dijkstra expanded **12 nodes (75% of campus)**, while A* expanded only **8 nodes** — a **33.3% reduction in search effort**!
4. **Switch to "Side-by-Side Dual View":**
   - Click the **"Side-by-Side Dual View"** button at the top right of the map.
   - Click **"Replay"**.
   - Show the professor how Dijkstra expands uniformly in circles like water ripples, while A* immediately lasers in towards the hospital.

### Expected Professor Questions & Answers:
- **Q: Why are the travel times identical between Dijkstra and A*?**
  *A: Because our heuristic function $h(n) = \text{Euclidean\_Dist} / V_{\max}$ is admissible (it never overestimates remaining time). By theorem, A* with an admissible heuristic is guaranteed to find an optimal path.*
- **Q: Why is node expansion count a better metric than CPU execution time here?**
  *A: On a 16-node graph, both algorithms execute in under 2 microseconds. Operating system task scheduling and cache warm-up introduce jitter at that sub-microsecond scale. Node expansions directly count algorithmic work (priority queue pops and edge relaxations), providing a machine-independent proof of A*'s efficiency.*
- **Q: What data structure powers your priority queue in C?**
  *A: A binary Min-Heap (`heap.c`), providing $O(\log V)$ insertions and extractions.*
